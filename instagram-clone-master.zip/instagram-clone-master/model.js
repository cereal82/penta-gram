Notes = new Mongo.Collection('notes');
